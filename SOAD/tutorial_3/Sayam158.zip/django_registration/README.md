Django Blog.<br />
This is Django web app which I created while learning Django. Feel free to add blogs over here.<br />
Go live - https://sayamkumar049.pythonanywhere.com/

Thanks
