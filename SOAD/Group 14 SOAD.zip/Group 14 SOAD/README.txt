This is the artifacts submission by Group 14.
This directory contains - 
1. Wireframe that highlights the skeleton of the website.
2. PPT that presents our idea.
3. Swagger Open API YML file.

Group members
S20180010158 - Sayam Kumar
S20180010064 - Hrishabh Pandey
S20180010141 - Raahul Singh
S20180010090 - Kudumula Hemanth
S20180010180 - Usarthi Harshini