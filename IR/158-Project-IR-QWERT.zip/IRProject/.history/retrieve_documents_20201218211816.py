import re
import math
import json
from src.query import QueryCheck
import argparse

parser = argparse.ArgumentParser(description="Process some integers.")
parser.add_argument("--query", type=str, help="input the query")

args = parser.parse_args()
query = args.query
query = query.lower()
query = re.sub("\d+", "", query)  # Remove digits
query = re.sub("[^\w\s]", " ", query)  # Remove punctuation
query = re.findall("[A-Za-z]+", query)  # Tokenize words
query = " ".join(query)

queryChecker = QueryCheck(query)

possibleQuery = queryChecker.getPossibleQuery()
suggested_query = possibleQuery[0]


query = suggested_query
merged_set = list()
initial = True
for word in query.split():
    posting_list = list()
    for i in range(4):
        file_name = f"posting_list_{i+1}/{word[0]}.json"
        with open(file_name) as f:
            data = json.load(f)
            if word in data:
                posting_list.extend(data[word])

    # Implementing tdidf
    for index in range(len(posting_list)):
        idf = math.log(500 / len(posting_list))
        posting_list[index][1] = 1 + math.log(posting_list[index][1]) * idf

    p_dict = dict()
    for i in posting_list:
        p_dict[i[0]] = i[1]

    if initial:
        merged_set = p_dict
        initial = False
    else:
        common_docs = set(merged_set.keys()).intersection(p_dict.keys())
        for doc in common_docs:
            merged_set[doc] = merged_set[doc] * p_dict[doc]

ans = sorted(merged_set.items(), key=lambda item: item[1], reverse=True)[:2]

root_id = str(input("Enter the root paper ID"))

from crawler import *

paper = GraphNode(ArXivPaper(root_id))

c_vs_r = int(input("Enter 0 for citation and 1 for references"))

g = Graph(paper)
if c_vs_r == 0:
    new_data = g.get_root_citations()
elif c_vs_r == 1:
    new_data = g.get_root_references()
