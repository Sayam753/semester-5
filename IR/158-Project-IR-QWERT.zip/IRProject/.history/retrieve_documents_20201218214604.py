import re
import math
import json
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from src.query import QueryCheck
import argparse

parser = argparse.ArgumentParser(description="Process some integers.")
parser.add_argument("--query", type=str, help="input the query")

args = parser.parse_args()
query = args.query
query = query.lower()
query = re.sub("\d+", "", query)  # Remove digits
query = re.sub("[^\w\s]", " ", query)  # Remove punctuation
query = re.findall("[A-Za-z]+", query)  # Tokenize words
query = " ".join(query)

queryChecker = QueryCheck(query)

possibleQuery = queryChecker.getPossibleQuery()
suggested_query = possibleQuery[0]


query = suggested_query
merged_set = list()
initial = True
for word in query.split():
    posting_list = list()
    for i in range(4):
        file_name = f"posting_list_{i+1}/{word[0]}.json"
        with open(file_name) as f:
            data = json.load(f)
            if word in data:
                posting_list.extend(data[word])

    # Implementing tdidf
    for index in range(len(posting_list)):
        idf = math.log(500 / len(posting_list))
        posting_list[index][1] = 1 + math.log(posting_list[index][1]) * idf

    p_dict = dict()
    for i in posting_list:
        p_dict[i[0]] = (i[1], i[2])

    if initial:
        merged_set = p_dict
        initial = False
    else:
        common_docs = set(merged_set.keys()).intersection(p_dict.keys())
        for doc in common_docs:
            merged_set[doc] = (merged_set[doc][0] * p_dict[doc][0], p_dict[doc][1])

ans = sorted(merged_set.items(), key=lambda item: item[1][0], reverse=True)[:2]

root_id = str(input("Enter the root paper ID"))

from crawler import *

paper = GraphNode(ArXivPaper(root_id))

c_vs_r = int(input("Enter 0 for citation and 1 for references"))

# Build root citations and references graph
g = Graph(paper)
if c_vs_r == 0:
    new_data = g.get_root_citations()
elif c_vs_r == 1:
    new_data = g.get_root_references()

while True:
    abstracts = list()

    for data in new_data:
        abstracts.append(data["abstract"])

    # tdidf to query with abstracts
    vectorize = TfidfVectorizer()
    X = vectorize.fit_transform(abstracts)

    for data, tdidf_score in zip(new_data, np.sum(vectorize.transform(query), axis=0)):
        # Pseudo relevance feeback
        data["rank"] = data["numCitations"] * 0.001 + tdidf_score

    # Sorting with respect to rank
    new_data = sorted(new_data.items(), key=lambda item: item[5], reverse=True)[:5]

    paper_id = str(input("Enter the paper ID"))
    c_vs_r = int(
        input(
            "Enter 0 for citation, 1 for references, 2 for printing citation, 3 for printing references, 4 for quit"
        )
    )
    if c_vs_r == 0:
        new_data = g.build_citations_subtree()
    elif c_vs_r == 1:
        new_data = g.build_references_subtree()
    elif c_vs_r == 2:
        print(g.citation_branch)
    elif c_vs_r == 3:
        print(g.reference_branch)
    else:
        quit()
