import joblib
import json
import numpy as np
import os
import pandas as pd
import re
import tqdm

from collections import Counter
from itertools import groupby
from joblib import Parallel, delayed
from pprint import pprint

# fmt: off
stop_words = ("a", "about", "above", "after", "again", "against", "ain", "all", "am", "an",
              "and", "any", "are", "aren", "aren't", "as", "at", "be", "because", "been",
              "before", "being", "below", "between", "both", "but", "by", "can", "couldn",
              "couldn't", "d", "did", "didn", "didn't", "do", "does", "doesn", "doesn't",
              "doing", "don", "don't", "down", "during", "each", "few", "for", "from",
              "further", "had", "hadn", "hadn't", "has", "hasn", "hasn't", "have", "haven",
              "haven't", "having", "he", "her", "here", "hers", "herself", "him", "himself",
              "his", "how", "i", "if", "in", "into", "is", "isn", "isn't", "it", "it's", "its",
              "itself", "just", "ll", "m", "ma", "me", "mightn", "mightn't", "more", "most", 
              "mustn", "mustn't", "my", "myself", "needn", "needn't", "no", "nor", "not", "now",
              "o", "of", "off", "on", "once", "only", "or", "other", "our", "ours", "ourselves",
              "out", "over", "own", "re", "s", "same", "shan", "shan't", "she", "she's", "should",
              "should've", "shouldn", "shouldn't", "so", "some", "such", "t", "than", "that", 
              "that'll", "the", "their", "theirs", "them", "themselves", "then", "there", "these",
              "they", "this", "those", "through", "to", "too", "under", "until", "up", "ve", "very",
              "was", "wasn", "wasn't", "we", "were", "weren", "weren't", "what", "when", "where",
              "which", "while", "who", "whom", "why", "will", "with", "won", "won't", "wouldn",
              "wouldn't", "y", "you", "you'd", "you'll", "you're", "you've", "your", "yours",
              "yourself", "yourselves", "could", "he'd", "he'll", "he's", "here's", "how's", "i'd",
              "i'll", "i'm", "i've", "let's", "ought", "she'd", "she'll", "that's", "there's", "they'd",
              "they'll", "they're", "they've", "we'd", "we'll", "we're", "we've", "what's", "when's",
              "where's", "who's", "why's", "would")
# fmt: on

with open("posting_list.json", "w") as file:
    json.dump(dict(), file)

data_size = 100_000
batch_size = data_size // 4

batch_list = list()
for i in range(4):
    batch_list.append([batch_size * i, batch_size * (i + 1)])
pprint(batch_list)

# Creating 4 sets of indices
for i in range(4):
    for j in range(ord("a"), ord("a") + 26):
        file_name = f"posting_list_{i+1}/{chr(j)}.json"
        with open(file_name, "w") as f:
            json.dump(dict(), f)


def process_batch(i, data, size):
    """Process batch and create inverted index."""
    posting_list = dict()
    for batch, point in zip(tqdm.tqdm(range(size)), data):

        # Preprocessing
        article_json = json.loads(point)
        article = article_json["abstract"].lower()
        article = re.sub("\d+", "", article)  # Remove digits
        article = re.sub("[^\w\s]", " ", article)  # Remove punctuation
        article = re.findall("[A-Za-z]+", article)  # Tokenize words
        data_dict = Counter(article)  # Create data dict

        # Removing stop words
        stop_words_in_data = set(data_dict).intersection(stop_words)
        for words in stop_words_in_data:
            del data_dict[words]

        for word, count in data_dict.items():
            if word in posting_list:
                posting_list[word].append((article_json["id"], count))
            else:
                posting_list[word] = [(article_json["id"], count)]

        if batch % 100 == 0 or batch == (len(data) - 1):
            for k, g in groupby(posting_list.keys(), key=lambda x: x[0]):
                g = list(g)
                temp_dict = {val: posting_list[val] for val in g}
                file_name = f"posting_list_{i+1}/{g[0][0]}.json"
                with open(file_name, "r") as f:
                    file_dict = json.load(f)

                    for word, value in temp_dict.items():
                        if word in file_dict:
                            file_dict[word].extend(value)
                        else:
                            file_dict[word] = value

                with open(file_name, "w") as f:
                    json.dump(file_dict, f)
            posting_list = dict()


with open("../input/arxiv/arxiv-metadata-oai-snapshot.json") as f:
    Parallel(n_jobs=4, backend="multiprocessing")(
        delayed(process_batch)(i, f.readlines()[batch_list[i][0] : batch_list[i][1]])
        for i in tqdm.tqdm(4)
    )
