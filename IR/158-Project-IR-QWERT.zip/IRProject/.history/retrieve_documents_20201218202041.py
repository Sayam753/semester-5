from src.query import QueryCheck
import argparse

parser = argparse.ArgumentParser(description='Process some integers.')
parser.add_argument('query', type=str
                    help='input the query')

queryChecker = QueryCheck("diphotun experinent")

# List of all word corrections
print("====== Correction Word wise =================")
wordCorrections = queryChecker.getCorrectedWords()
for wordObj in wordCorrections:
    print(wordObj)
print("=============================================")

# List of all possible query
print("====== Possible Query ( depth = 3 ) ==========")
possibleQuery = queryChecker.getPossibleQuery()
for queries in possibleQuery:
    print(queries)
print("=============================================")

