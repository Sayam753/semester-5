import re
from src.query import QueryCheck
import argparse

parser = argparse.ArgumentParser(description="Process some integers.")
parser.add_argument("--query", type=str, help="input the query")

args = parser.parse_args()
query = args.query
query = query.lower()
query = re.sub("\d+", "", query)  # Remove digits
query = re.sub("[^\w\s]", " ", query)  # Remove punctuation
query = re.findall("[A-Za-z]+", query)  # Tokenize words
query = " ".join(query)

queryChecker = QueryCheck(query)

possibleQuery = queryChecker.getPossibleQuery()
suggested_query = possibleQuery[0]
