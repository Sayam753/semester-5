rm -rf posting*

# Create 4 posting list directories
mkdir posting_list_1
mkdir posting_list_2
mkdir posting_list_3
mkdir posting_list_4

pip install -r requirements.txt